﻿namespace miniproj.Infrastructure;

public class Class1
{

}
