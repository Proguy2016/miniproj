﻿namespace miniproj.Application;

public class Class1
{

}
