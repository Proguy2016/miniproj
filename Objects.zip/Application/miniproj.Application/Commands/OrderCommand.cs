using MediatR;
namespace miniproj.Application.Commands
{
    public class OrderCommand : IRequest
    {
        public Guid Id { get; } = Guid.NewGuid();
        public Guid UserId { get; }
        public decimal Amount { get; }
        public string Currency { get; }

        public OrderCommand(Guid userId, decimal amount, string currency)
        {
            UserId = userId;
            Amount = amount;
            Currency = currency;
        }
    }
}