﻿namespace miniproj.Domain;

public class Class1
{

}
